package com.google.maps.android.geojson;

import junit.framework.TestCase;

public class GeoJsonRendererTest extends TestCase {

    public void setUp() throws Exception {
        super.setUp();

    }

    public void tearDown() throws Exception {

    }

    public void testGetMap() throws Exception {

    }

    public void testSetMap() throws Exception {

    }

    public void testGetFeatures() throws Exception {

    }

    public void testAddFeature() throws Exception {

    }

    public void testRemoveLayerFromMap() throws Exception {

    }

    public void testRemoveFeature() throws Exception {

    }
}